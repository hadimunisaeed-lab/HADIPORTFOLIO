# Muhammed Hadi — Architect Portfolio

A responsive, recruiter-friendly portfolio website for Muhammed Hadi, an architect working on residential and commercial projects in the UAE. The site leads with project work (case studies with image galleries), then experience, skills, education and contact details. It supports light and dark mode.

**Suggested repository name:** `muhammed-hadi-architect-portfolio`

## Technology stack

- Next.js 14 (App Router) and React 18
- Tailwind CSS 3
- TypeScript
- Google Fonts via `next/font` (Instrument Serif, Hanken Grotesk)

No API keys or environment variables are needed.

## Run locally

Requires Node.js 18.17 or newer.

```bash
npm install
npm run dev
```

Open http://localhost:3000. The first run needs an internet connection so `next/font` can download the two fonts.

To build for production: `npm run build` then `npm start`.

## Project structure

```
├── public/projects/          Project images (cropped from the portfolio PDF)
├── src/
│   ├── app/                  layout.tsx, page.tsx, globals.css
│   ├── components/           Header, Hero, About, Work, Lightbox, Experience,
│   │                         Skills, Education, Contact, Footer, Reveal, ThemeToggle
│   └── data/portfolio.ts     ALL site content
├── next.config.mjs
├── tailwind.config.ts
├── postcss.config.mjs
└── tsconfig.json
```

## Customise the content

Almost everything is edited in **`src/data/portfolio.ts`**:

- `profile`: name, headline, contact details, LinkedIn and flipbook links. Set `cvUrl` to show a "Download CV" button (put the PDF in `public/`, for example `/Muhammed-Hadi-CV.pdf`).
- `about`: the introduction paragraphs and focus list.
- `featured`: the four lead case studies shown at the top of the Work section.
- `moreWork`: grouped projects shown as a grid; each opens a gallery.
- `experience`, `skills`, `education`.

To add a project, drop its images into `public/projects/` and add an entry to `featured` or `moreWork` with `src: "/projects/your-image.jpg"`.

Colours are CSS variables at the top of `src/app/globals.css`; change `--clay` to alter the accent colour.

## Notes

- Developer marketing images in "Urban Residential Developments" are credited as courtesy of the respective developers, and the technical drawings from that role are confidential and are not shown.
- Replace the cropped images in `public/projects/` with originals at higher resolution when available.
