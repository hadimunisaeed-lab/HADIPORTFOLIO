import { experience } from "@/data/portfolio";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

export default function Experience() {
  return (
    <section id="experience" className="border-t border-line">
      <div className="mx-auto max-w-page px-5 py-20 sm:px-8 md:py-28">
        <SectionHeading number="03" label="Experience" title="From studio to site." />
        <div className="divide-y divide-line border-y border-line">
          {experience.map((job) => (
            <Reveal key={`${job.company}-${job.role}`}>
              <div className="grid gap-4 py-8 md:grid-cols-12 md:gap-10">
                <div className="md:col-span-3">
                  <p className="text-sm text-muted">{job.period}</p>
                  <p className="mt-1 text-sm text-muted">{job.place}</p>
                </div>
                <div className="md:col-span-9">
                  <h3 className="font-display text-3xl">
                    {job.role} <span className="text-muted">·</span> {job.company}
                  </h3>
                  <ul className="mt-4 space-y-2 leading-relaxed">
                    {job.points.map((p) => (
                      <li key={p} className="flex gap-3">
                        <span className="mt-3 h-px w-4 shrink-0 bg-clay" />
                        <span>{p}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
