import { about } from "@/data/portfolio";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

export default function About() {
  return (
    <section id="about" className="border-t border-line">
      <div className="mx-auto max-w-page px-5 py-20 sm:px-8 md:py-28">
        <SectionHeading number="01" label="About" title="Design that survives construction." />
        <Reveal>
          <div className="grid gap-10 lg:grid-cols-12">
            <div className="space-y-5 text-lg leading-relaxed lg:col-span-7">
              {about.paragraphs.map((p) => (
                <p key={p}>{p}</p>
              ))}
            </div>
            <div className="lg:col-span-4 lg:col-start-9">
              <p className="eyebrow">Focus</p>
              <ul className="mt-4 divide-y divide-line border-y border-line">
                {about.focus.map((f) => (
                  <li key={f} className="py-3 text-sm">
                    {f}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
