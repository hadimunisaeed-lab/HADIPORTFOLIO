import { profile } from "@/data/portfolio";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

export default function Contact() {
  const rows = [
    { label: "Email", value: profile.email, href: `mailto:${profile.email}` },
    { label: "Phone", value: profile.phone, href: `tel:${profile.phone.replace(/\s/g, "")}` },
    { label: "LinkedIn", value: "linkedin.com/in/muhdhadi1188", href: profile.linkedin },
    { label: "Full portfolio", value: "Open the portfolio flipbook", href: profile.flipbook },
    { label: "Based in", value: `${profile.location} · ${profile.licence}`, href: "" },
  ];

  return (
    <section id="contact" className="border-t border-line">
      <div className="mx-auto max-w-page px-5 py-20 sm:px-8 md:py-28">
        <SectionHeading number="06" label="Contact" title="Let's talk about your project." />
        <Reveal>
          <div className="grid gap-12 lg:grid-cols-12">
            <p className="max-w-md text-lg leading-relaxed lg:col-span-5">
              For architectural design, technical coordination or BIM work, email is the quickest way to reach me.
            </p>
            <dl className="divide-y divide-line border-y border-line lg:col-span-7">
              {rows.map((r) => (
                <div key={r.label} className="grid gap-1 py-4 sm:grid-cols-3 sm:gap-6">
                  <dt className="eyebrow self-center">{r.label}</dt>
                  <dd className="sm:col-span-2">
                    {r.href ? (
                      <a
                        href={r.href}
                        target={r.href.startsWith("http") ? "_blank" : undefined}
                        rel={r.href.startsWith("http") ? "noopener noreferrer" : undefined}
                        className="break-all underline-offset-4 transition hover:text-clay hover:underline"
                      >
                        {r.value}
                      </a>
                    ) : (
                      <span>{r.value}</span>
                    )}
                  </dd>
                </div>
              ))}
            </dl>
          </div>
        </Reveal>
      </div>
    </section>
  );
}
