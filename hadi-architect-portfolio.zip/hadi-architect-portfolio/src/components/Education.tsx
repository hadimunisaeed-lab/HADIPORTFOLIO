import { education } from "@/data/portfolio";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

export default function Education() {
  return (
    <section id="education" className="border-t border-line">
      <div className="mx-auto max-w-page px-5 py-20 sm:px-8 md:py-28">
        <SectionHeading number="05" label="Education & certification" title="Training." />
        <Reveal>
          <div className="divide-y divide-line border-y border-line">
            {education.map((e) => (
              <div key={e.title} className="grid gap-2 py-6 md:grid-cols-12 md:gap-10">
                <p className="text-sm text-muted md:col-span-3">{e.period}</p>
                <div className="md:col-span-9">
                  <h3 className="font-display text-2xl">{e.title}</h3>
                  <p className="mt-1 text-sm text-muted">{e.place}</p>
                </div>
              </div>
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}
