import { profile } from "@/data/portfolio";

export default function Footer() {
  return (
    <footer className="border-t border-line">
      <div className="mx-auto flex max-w-page flex-col gap-2 px-5 py-8 text-xs text-muted sm:flex-row sm:items-center sm:justify-between sm:px-8">
        <p>
          © {new Date().getFullYear()} {profile.name}. All project images are the property of their respective owners.
        </p>
        <a href="#top" className="transition hover:text-ink">
          Back to top ↑
        </a>
      </div>
    </footer>
  );
}
