export default function SectionHeading({
  number,
  label,
  title,
}: {
  number: string;
  label: string;
  title: string;
}) {
  return (
    <div className="mb-12 md:mb-16">
      <div className="flex items-center gap-4">
        <span className="eyebrow">{number}</span>
        <span className="h-px w-10 bg-line" />
        <span className="eyebrow">{label}</span>
      </div>
      <h2 className="mt-5 font-display text-4xl leading-[1.05] sm:text-5xl md:text-6xl">{title}</h2>
    </div>
  );
}
