"use client";

import { useCallback, useState } from "react";
import { featured, moreWork, type Project } from "@/data/portfolio";
import Lightbox from "./Lightbox";
import Reveal from "./Reveal";
import SectionHeading from "./SectionHeading";

type Active = { project: Project; index: number } | null;

export default function Work() {
  const [active, setActive] = useState<Active>(null);

  const open = (project: Project, index = 0) => setActive({ project, index });
  const close = useCallback(() => setActive(null), []);
  const setIndex = useCallback(
    (index: number) => setActive((a) => (a ? { ...a, index } : a)),
    []
  );

  return (
    <section id="work" className="border-t border-line">
      <div className="mx-auto max-w-page px-5 py-20 sm:px-8 md:py-28">
        <SectionHeading number="02" label="Selected work" title="Four projects to start with." />

        <div className="space-y-24 md:space-y-32">
          {featured.map((project, i) => (
            <Reveal key={project.slug}>
              <article className="grid gap-8 lg:grid-cols-12 lg:gap-12">
                <div className={`lg:col-span-7 ${i % 2 === 1 ? "lg:order-2" : ""}`}>
                  <button
                    type="button"
                    onClick={() => open(project, 0)}
                    className="group block w-full overflow-hidden border border-line text-left"
                    aria-label={`Open ${project.title} gallery`}
                  >
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={project.images[0].src}
                      alt={project.images[0].alt}
                      loading="lazy"
                      decoding="async"
                      className="aspect-[4/3] w-full object-cover transition duration-700 group-hover:scale-[1.02]"
                    />
                  </button>
                  {project.images.length > 1 && (
                    <div className="mt-3 grid grid-cols-4 gap-3">
                      {project.images.slice(1, 5).map((img, k) => (
                        <button
                          key={img.src}
                          type="button"
                          onClick={() => open(project, k + 1)}
                          className="overflow-hidden border border-line"
                          aria-label={`Open image: ${img.alt}`}
                        >
                          {/* eslint-disable-next-line @next/next/no-img-element */}
                          <img
                            src={img.src}
                            alt={img.alt}
                            loading="lazy"
                            decoding="async"
                            className="aspect-[4/3] w-full object-cover opacity-90 transition hover:opacity-100"
                          />
                        </button>
                      ))}
                    </div>
                  )}
                </div>

                <div className="lg:col-span-5">
                  <p className="eyebrow">
                    {String(i + 1).padStart(2, "0")} · {project.category}
                  </p>
                  <h3 className="mt-4 font-display text-4xl leading-tight md:text-5xl">{project.title}</h3>
                  <p className="mt-2 text-sm text-muted">{project.location}</p>
                  <p className="mt-6 leading-relaxed">{project.summary}</p>

                  {project.points && (
                    <ul className="mt-6 space-y-2.5 border-t border-line pt-6 text-sm leading-relaxed">
                      {project.points.map((pt) => (
                        <li key={pt} className="flex gap-3">
                          <span className="mt-2 h-px w-4 shrink-0 bg-clay" />
                          <span>{pt}</span>
                        </li>
                      ))}
                    </ul>
                  )}

                  {project.tags && (
                    <div className="mt-6 flex flex-wrap gap-2">
                      {project.tags.map((t) => (
                        <span key={t} className="chip">
                          {t}
                        </span>
                      ))}
                    </div>
                  )}

                  {project.note && <p className="mt-6 text-xs italic leading-relaxed text-muted">{project.note}</p>}

                  <button
                    type="button"
                    onClick={() => open(project, 0)}
                    className="mt-8 text-sm font-medium underline underline-offset-4 transition hover:text-clay"
                  >
                    View {project.images.length} {project.images.length === 1 ? "image" : "images"} →
                  </button>
                </div>
              </article>
            </Reveal>
          ))}
        </div>

        <div className="mt-28 md:mt-36">
          <h3 className="font-display text-3xl md:text-4xl">More work</h3>
          <p className="mt-3 max-w-xl text-sm text-muted">
            Architecture, interiors, exhibition design and documentation. Select any project to open its gallery.
          </p>

          <div className="mt-12 space-y-14">
            {moreWork.map((g) => (
              <Reveal key={g.group}>
                <div className="flex items-center gap-4">
                  <span className="eyebrow">{g.group}</span>
                  <span className="h-px flex-1 bg-line" />
                </div>
                <div className="mt-6 grid gap-x-6 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
                  {g.projects.map((p) => (
                    <button
                      key={p.slug}
                      type="button"
                      onClick={() => open(p, 0)}
                      className="group text-left"
                    >
                      <div className="overflow-hidden border border-line">
                        {/* eslint-disable-next-line @next/next/no-img-element */}
                        <img
                          src={p.images[0].src}
                          alt={p.images[0].alt}
                          loading="lazy"
                          decoding="async"
                          className="aspect-[4/3] w-full object-cover transition duration-700 group-hover:scale-[1.03]"
                        />
                      </div>
                      <p className="mt-4 font-display text-2xl transition group-hover:text-clay">{p.title}</p>
                      <p className="mt-1 text-xs text-muted">
                        {p.category} · {p.location}
                      </p>
                    </button>
                  ))}
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>

      {active && <Lightbox project={active.project} index={active.index} onIndex={setIndex} onClose={close} />}
    </section>
  );
}
