import { featured, profile } from "@/data/portfolio";

export default function Hero() {
  const hq = featured.find((p) => p.slug === "confident-group-hq")!;

  return (
    <section id="top" className="mx-auto max-w-page px-5 pb-20 pt-14 sm:px-8 md:pb-28 md:pt-20">
      <div className="grid items-end gap-12 lg:grid-cols-12">
        <div className="lg:col-span-6">
          <p className="eyebrow">{profile.title} · Dubai &amp; Sharjah, UAE</p>
          <h1 className="mt-6 font-display text-6xl leading-[0.95] sm:text-7xl xl:text-8xl">
            Muhammed
            <br />
            <span className="italic text-clay">Hadi</span>
          </h1>
          <p className="mt-8 max-w-xl text-lg leading-relaxed text-ink/90">{profile.positioning}</p>
          <p className="mt-4 max-w-xl text-sm text-muted">{profile.headline}</p>

          <div className="mt-10 flex flex-wrap gap-3">
            <a
              href="#work"
              className="bg-ink px-6 py-3 text-sm font-medium text-paper transition hover:bg-clay"
            >
              View selected work
            </a>
            <a
              href="#contact"
              className="border border-ink px-6 py-3 text-sm font-medium transition hover:border-clay hover:text-clay"
            >
              Get in touch
            </a>
            {profile.cvUrl && (
              <a
                href={profile.cvUrl}
                className="px-2 py-3 text-sm font-medium underline underline-offset-4 hover:text-clay"
              >
                Download CV
              </a>
            )}
          </div>

          {/* Dimension-line motif: the design-to-construction approach */}
          <div className="mt-14 flex items-center gap-3 text-xs uppercase tracking-[0.18em] text-muted">
            <span>Concept</span>
            <span className="relative h-px flex-1 bg-line">
              <span className="absolute -left-px -top-1.5 h-3 w-px bg-ink" />
              <span className="absolute -right-px -top-1.5 h-3 w-px bg-ink" />
            </span>
            <span>Site</span>
          </div>
        </div>

        <figure className="lg:col-span-6">
          <div className="relative border border-line p-2">
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img
              src={hq.images[0].src}
              alt={hq.images[0].alt}
              className="aspect-[4/3] w-full object-cover"
              fetchPriority="high"
            />
          </div>
          {/* Title block, as on a drawing sheet */}
          <figcaption className="grid grid-cols-3 border border-t-0 border-line text-xs">
            <div className="border-r border-line p-3">
              <div className="eyebrow !text-[10px]">Project</div>
              <div className="mt-1">Confident Group HQ</div>
            </div>
            <div className="border-r border-line p-3">
              <div className="eyebrow !text-[10px]">Type</div>
              <div className="mt-1">Commercial</div>
            </div>
            <div className="p-3">
              <div className="eyebrow !text-[10px]">Location</div>
              <div className="mt-1">Dubai, UAE</div>
            </div>
          </figcaption>
        </figure>
      </div>

      <dl className="mt-16 grid grid-cols-1 border-y border-line sm:grid-cols-3">
        {[
          ["Currently", "Architect, Petra Point, Dubai"],
          ["Certified", "A.BIM (Architecture)"],
          ["Software", "Revit · AutoCAD · Lumion"],
        ].map(([k, v]) => (
          <div key={k} className="border-b border-line px-1 py-5 last:border-b-0 sm:border-b-0 sm:border-r sm:px-6 sm:last:border-r-0 sm:first:pl-1">
            <dt className="eyebrow">{k}</dt>
            <dd className="mt-1.5 text-sm">{v}</dd>
          </div>
        ))}
      </dl>
    </section>
  );
}
