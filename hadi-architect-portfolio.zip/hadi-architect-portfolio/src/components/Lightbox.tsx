"use client";

import { useEffect } from "react";
import type { Project } from "@/data/portfolio";

type Props = {
  project: Project;
  index: number;
  onIndex: (i: number) => void;
  onClose: () => void;
};

export default function Lightbox({ project, index, onIndex, onClose }: Props) {
  const total = project.images.length;
  const image = project.images[index];

  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") onIndex((index + 1) % total);
      if (e.key === "ArrowLeft") onIndex((index - 1 + total) % total);
    }
    window.addEventListener("keydown", onKey);
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prev;
    };
  }, [index, total, onIndex, onClose]);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={project.title}
      className="fixed inset-0 z-50 flex flex-col bg-paper"
    >
      <div className="flex items-center justify-between border-b border-line px-5 py-3 sm:px-8">
        <div className="min-w-0">
          <p className="truncate font-display text-xl">{project.title}</p>
          <p className="truncate text-xs text-muted">
            {project.category} · {project.location}
          </p>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="ml-4 border border-line px-4 py-2 text-sm transition hover:border-ink"
        >
          Close
        </button>
      </div>

      <div className="relative flex min-h-0 flex-1 items-center justify-center p-4 sm:p-8">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img
          src={image.src}
          alt={image.alt}
          className="max-h-full max-w-full object-contain"
        />
        {total > 1 && (
          <>
            <button
              type="button"
              aria-label="Previous image"
              onClick={() => onIndex((index - 1 + total) % total)}
              className="absolute left-2 top-1/2 -translate-y-1/2 border border-line bg-paper/90 px-3 py-3 text-lg transition hover:border-ink sm:left-6"
            >
              ←
            </button>
            <button
              type="button"
              aria-label="Next image"
              onClick={() => onIndex((index + 1) % total)}
              className="absolute right-2 top-1/2 -translate-y-1/2 border border-line bg-paper/90 px-3 py-3 text-lg transition hover:border-ink sm:right-6"
            >
              →
            </button>
          </>
        )}
      </div>

      <div className="border-t border-line px-5 py-3 text-sm sm:px-8">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <p className="text-muted">{image.alt}</p>
          <p className="text-xs text-muted">
            {index + 1} / {total}
          </p>
        </div>
      </div>
    </div>
  );
}
