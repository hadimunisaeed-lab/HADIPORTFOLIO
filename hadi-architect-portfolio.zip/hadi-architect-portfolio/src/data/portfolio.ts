/**
 * All site content lives here. Edit this file to update the portfolio.
 * Every entry comes from the CV, LinkedIn profile and portfolio PDF.
 */

export type ProjectImage = { src: string; alt: string };

export type Project = {
  slug: string;
  title: string;
  category: string;
  location: string;
  summary: string;
  /** Short factual points taken from the portfolio slides. */
  points?: string[];
  tags?: string[];
  note?: string;
  images: ProjectImage[];
};

export const profile = {
  name: "Muhammed Hadi",
  title: "Architect",
  headline:
    "BIM Certified · Architectural Design & Technical Coordination · Residential & Commercial",
  positioning:
    "Residential and commercial architecture, taken from design development and construction documentation through authority approvals and site execution.",
  location: "Sharjah, UAE",
  email: "muhdhadi1188@gmail.com",
  phone: "+971 50 188 0696",
  linkedin: "https://www.linkedin.com/in/muhdhadi1188/",
  flipbook: "https://online.fliphtml5.com/emfba/gnpf/",
  /** Put a PDF in /public (e.g. /public/Muhammed-Hadi-CV.pdf) and set "/Muhammed-Hadi-CV.pdf" to show a CV button. */
  cvUrl: "",
  licence: "UAE driving licence",
};

export const about = {
  paragraphs: [
    "I'm an architect working on residential and commercial projects in the UAE. At Petra Point in Dubai I prepare architectural designs, drawings and presentations, coordinate BIM, survey and consultant inputs, and oversee work on site.",
    "My approach connects design to construction: concepts that stay creative and functional, and that remain buildable once they reach drawings, approvals and site. I'm BIM-trained (A.BIM) and work in Revit, AutoCAD and 3D visualisation.",
  ],
  focus: ["Residential", "Commercial", "Interiors & fit-out", "Exhibition design"],
};

export const featured: Project[] = [
  {
    slug: "urban-residential-developments",
    title: "Urban Residential Developments",
    category: "Professional work · Large-scale residential & mixed-use",
    location: "Dubai, UAE · Petra Point",
    summary:
      "Contributing as an architect to large-scale residential and mixed-use developments across Dubai. The role centres on architectural documentation, spatial analysis, site coordination and design development within multidisciplinary project teams.",
    points: [
      "High-rise residential developments",
      "Branded luxury residential projects",
      "Mixed-use masterplans",
      "Large-scale urban communities in Dubai",
      "Projects include Bugatti Residences, Mercedes-Benz Places, Meriva Collection, Burj Binghatti, Sky Terraces, Binghatti Skyflame, Damac Lagoon Views, Shahrukhz by Danube and Serenz",
    ],
    tags: [
      "Architectural drawing",
      "Design coordination",
      "Technical documentation",
      "Site surveys",
      "Area calculation",
      "Marketing support",
      "BIM documentation",
    ],
    note: "Images are publicly available marketing materials, courtesy of the respective developers. Technical drawings and documentation produced in this role are confidential and not for public release.",
    images: [
      {
        src: "/projects/urban-grid.jpg",
        alt: "Nine Dubai residential developments from developer marketing material",
      },
    ],
  },
  {
    slug: "anwers-retreat",
    title: "Anwer's Retreat",
    category: "Residential villa",
    location: "Syouh, Sharjah, UAE",
    summary:
      "A villa that blends traditional Arabic architectural elegance with modern refinement. The façade is defined by arches, geometric patterns and carefully crafted columns.",
    points: [
      "Ground and first floor plans developed with the façade design",
      "Rendered from multiple exterior viewpoints",
    ],
    images: [
      { src: "/projects/anwer-1.jpg", alt: "Anwer's Retreat main façade render" },
      { src: "/projects/anwer-plans.jpg", alt: "Anwer's Retreat ground and first floor plans" },
      { src: "/projects/anwer-renders.jpg", alt: "Four exterior views of Anwer's Retreat" },
    ],
  },
  {
    slug: "floating-community",
    title: "Floating Community",
    category: "Hospitality proposal",
    location: "Universal proposal",
    summary:
      "A floating community inspired by the movement of stingrays, designed to be self-sufficient and expandable. It addresses power, water, waste, food, transport and community facilities so that residents can live in balance with the surrounding water.",
    points: [
      "Master plan of 14 elements: apartments, villas, admin block, scuba diving block, play area, retail, floating walkways, viewpoint, event platform, floating auditorium, agri pods, service block, water-metro points and floating gym",
      "Pontoon principles: buoyant, stable, resilient and mobile, with EPS-filled pontoons that can be prefabricated, towed to site, docked and interconnected",
      "Housing developed around a central courtyard with boat parking; apartment types and two villa types drawn in plan and section",
    ],
    images: [
      { src: "/projects/floating-1.jpg", alt: "Aerial render of the floating community" },
      { src: "/projects/floating-plan.jpg", alt: "Stingray-shaped master plan" },
      { src: "/projects/floating-units.jpg", alt: "Apartment, villa plans and sections" },
      { src: "/projects/floating-principles.jpg", alt: "Pontoon principles and water supply plan" },
      { src: "/projects/floating-2.jpg", alt: "Community pavilion and funnel structures" },
      { src: "/projects/floating-renders.jpg", alt: "Sports courts, event platform and funnel structures" },
    ],
  },
  {
    slug: "confident-group-hq",
    title: "Confident Group HQ",
    category: "Commercial · Headquarters",
    location: "Dubai, UAE",
    summary:
      "A headquarters building with a wave-form façade of vertical fins and integrated warm lighting. The ground floor plan responds to a detailed programme of public and private entries, meeting spaces and a project presentation area.",
    points: [
      "Ground floor programme: public and gated private entries, reception and waiting, kids' look-after area, closed and open meeting rooms, coffee bar",
      "Amphitheatre-style presentation area for 40 seats with an LED wall, plus six maquette display positions",
    ],
    images: [
      { src: "/projects/hq-1.jpg", alt: "Confident Group HQ at night from the front" },
      { src: "/projects/hq-plan.jpg", alt: "Ground floor plan and requirements table" },
      { src: "/projects/hq-2.jpg", alt: "Confident Group HQ façade at night" },
      { src: "/projects/hq-3.jpg", alt: "Ground floor glazing and canopy detail" },
    ],
  },
];

export const moreWork: { group: string; projects: Project[] }[] = [
  {
    group: "Architecture",
    projects: [
      {
        slug: "solitude-living",
        title: "Solitude Living",
        category: "Residential retreat",
        location: "Wayanad, Kerala",
        summary:
          "A compact single-occupancy retreat set in a dense forest. The design explores minimal living through a bold sculptural A-frame form, natural light and atmospheric spaces, with a double-height volume and full-height glazing and a restrained palette of dark timber cladding.",
        images: [
          { src: "/projects/solitude-1.jpg", alt: "Solitude Living in forest light" },
          { src: "/projects/solitude-concept.jpg", alt: "Concept, design intent and key qualities" },
          { src: "/projects/solitude-2.jpg", alt: "Two exterior views of the retreat" },
          { src: "/projects/solitude-plans.jpg", alt: "Ground and first floor plans" },
          { src: "/projects/solitude-3.jpg", alt: "A minimal forest retreat at sunset" },
        ],
      },
      {
        slug: "clubhouse",
        title: "Clubhouse",
        category: "Hospitality",
        location: "Kozhikode, Kerala",
        summary:
          "A recreational clubhouse for a 50-unit apartment complex on a river bank. Curved forms inspired by kinematic architecture follow the site contours and act as privacy buffers between public recreation and private residences.",
        images: [
          { src: "/projects/club-1.jpg", alt: "Clubhouse curved stone and glass volume" },
          { src: "/projects/club-2.jpg", alt: "Clubhouse lawn and palm trees" },
          { src: "/projects/club-plans.jpg", alt: "Clubhouse floor plans" },
          { src: "/projects/club-3.jpg", alt: "Roof void and glazed façade" },
        ],
      },
    ],
  },
  {
    group: "Interiors",
    projects: [
      {
        slug: "alfain-residence",
        title: "Alfain Residence",
        category: "Residential interior",
        location: "Kerala (UAE client)",
        summary:
          "Modern contemporary with organic and mid-century touches: clean lines, curved furniture, warm earth tones and a mix of metals and natural textures.",
        images: [
          { src: "/projects/alfain-1.jpg", alt: "Alfain Residence lounge from above" },
          { src: "/projects/alfain-2.jpg", alt: "Living room with rust and cream sofas" },
          { src: "/projects/alfain-3.jpg", alt: "Open plan with floating staircase" },
          { src: "/projects/alfain-4.jpg", alt: "Dining area with fluted glass screen" },
        ],
      },
      {
        slug: "le-presidium",
        title: "Le Presidium",
        category: "Residential interior",
        location: "Silicon Oasis, Dubai, UAE",
        summary:
          "A luxury apartment in warm walnut and stone: a smoked walnut slat wall anchors the master bedroom, and the kitchen pairs dark walnut cabinetry with Calacatta marble.",
        images: [
          { src: "/projects/presidium-1.jpg", alt: "Le Presidium living room" },
          { src: "/projects/presidium-2.jpg", alt: "Master bedroom with walnut slat wall" },
          { src: "/projects/presidium-3.jpg", alt: "Kitchen with central island" },
          { src: "/projects/presidium-plan.jpg", alt: "Apartment plan" },
          { src: "/projects/presidium-4.jpg", alt: "Living space in calm, warm tones" },
          { src: "/projects/presidium-palette.jpg", alt: "Colour and material palette" },
        ],
      },
      {
        slug: "damask-suite",
        title: "The Damask Suite",
        category: "Residential interior",
        location: "Al Jada, Sharjah, UAE",
        summary:
          "A calm, transitional bedroom blending warm natural oak millwork, classical patterned wallpaper wainscoting and an integrated modern storage solution.",
        images: [
          { src: "/projects/damask-1.jpg", alt: "Damask Suite bedroom" },
          { src: "/projects/damask-2.jpg", alt: "Master bed against patterned wall band" },
          { src: "/projects/damask-3.jpg", alt: "Integrated wardrobe and desk wall" },
        ],
      },
      {
        slug: "executive-suite",
        title: "The Executive Suite",
        category: "Commercial fit-out",
        location: "Dubai, UAE",
        summary:
          "A modern corporate office combining fluted acoustic wall panelling, a concrete-finish accent wall with linear lighting, and a refined executive desk setup.",
        images: [
          { src: "/projects/exec-1.jpg", alt: "Executive office with fluted panelling" },
          { src: "/projects/exec-2.jpg", alt: "Seating zone and alternate desk angle" },
        ],
      },
      {
        slug: "nyla-abaya",
        title: "Nyla Abaya",
        category: "Commercial · Retail boutique",
        location: "Muwailah, Sharjah, UAE",
        summary:
          "A luxury abaya boutique in polished black-and-white marble, matte black display panels and brushed brass hanging racks, with a clear layout of floor sightlines, a focused reception desk and perimeter garment hanging.",
        images: [
          { src: "/projects/nyla-1.jpg", alt: "Nyla Abaya boutique exterior at night" },
          { src: "/projects/nyla-2.jpg", alt: "Boutique interior with arches" },
          { src: "/projects/nyla-3.jpg", alt: "Brass garment rails" },
          { src: "/projects/nyla-4.jpg", alt: "Marble floor and brass rails" },
          { src: "/projects/nyla-5.jpg", alt: "Slatted metallic reception desk" },
        ],
      },
    ],
  },
  {
    group: "Exhibition design",
    projects: [
      {
        slug: "bristol",
        title: "Bristol",
        category: "Exhibition stand",
        location: "Dubai · Freelance for Expo Magic LLC",
        summary:
          "Exhibition stand design for Bristol, a vehicle manufacturing division, built around a displayed ambulance, meeting tables and a branded reception counter.",
        images: [
          { src: "/projects/bristol-1.jpg", alt: "Bristol stand perspective" },
          { src: "/projects/bristol-2.jpg", alt: "Bristol stand front view" },
        ],
      },
      {
        slug: "dentium",
        title: "Dentium",
        category: "Exhibition stand",
        location: "Dubai · Freelance for Expo Magic LLC",
        summary:
          "Exhibition stand design for Dentium with a sweeping branded canopy form, product display counters and a suspended logo ring.",
        images: [
          { src: "/projects/dentium-1.jpg", alt: "Dentium stand perspective" },
          { src: "/projects/dentium-2.jpg", alt: "Dentium stand views and plan" },
        ],
      },
    ],
  },
  {
    group: "Documentation & design",
    projects: [
      {
        slug: "fit-out-working-drawing",
        title: "Fit-out Working Drawing",
        category: "Residential · Technical drawings",
        location: "50 Cross Road",
        summary:
          "Bedroom headwall elevations across multiple unit types, capturing the joinery specifications, material finishes and dimensional accuracy needed for on-site execution.",
        images: [
          { src: "/projects/fitout.jpg", alt: "Bedroom renders paired with headwall working drawings" },
        ],
      },
      {
        slug: "flute-bar-stool",
        title: "The Flute Bar Stool",
        category: "Product design",
        location: "Furniture",
        summary:
          "A bar stool bridging sculptural minimalism and architectural permanence for high-end residential and hospitality settings. 480 × 520 × 980 mm with a 750 mm seat height, in charcoal-stained solid ash, cream fabric and brushed brass.",
        images: [
          { src: "/projects/stool-1.jpg", alt: "The Flute Bar Stool" },
          { src: "/projects/stool-drawing.jpg", alt: "Dimensioned stool drawings" },
          { src: "/projects/stool-3.jpg", alt: "Stool views and bar setting" },
        ],
      },
      {
        slug: "visualisation",
        title: "Visualisation",
        category: "3D visualisation",
        location: "Selected renders",
        summary:
          "A selection of architectural renders from different stages and projects across my career, reflecting design intent, material exploration and visual development.",
        images: [{ src: "/projects/visual.jpg", alt: "Grid of architectural renders" }],
      },
    ],
  },
];

export const experience = [
  {
    role: "Architect",
    company: "Petra Point",
    place: "Dubai, UAE",
    period: "Aug 2025 – Present",
    points: [
      "Prepare architectural designs, drawings and presentations for residential and commercial projects.",
      "Coordinate with BIM and survey teams and with authorities for approvals and as-built documentation.",
      "Oversee on-site execution, ensuring quality, compliance and design accuracy.",
    ],
  },
  {
    role: "Freelance Architect",
    company: "Independent",
    place: "UAE",
    period: "From Jan 2023",
    points: [
      "Architectural consultant on shops, villas and apartments.",
      "Architectural design and planning, with 2D and 3D design for commercial and residential work.",
      "Site visits and coordination of project requirements during execution.",
      "Exhibition stand design for Expo Magic LLC, Dubai.",
    ],
  },
  {
    role: "Junior Architect",
    company: "Greek House",
    place: "Sharjah, UAE",
    period: "Jun 2024 – Jul 2025",
    points: [
      "Developed detailed architectural plans and designs aligned with client requirements.",
      "Worked with clients to refine concepts and ensure project satisfaction.",
      "Coordinated with construction teams on adherence to designs and timelines, and helped solve design challenges during construction.",
    ],
  },
  {
    role: "Intern Architect",
    company: "Architectural Studio",
    place: "Calicut, Kerala, India",
    period: "2023 – 2024",
    points: [
      "Assisted on small-scale architectural design projects, preparing drafts and drawings.",
      "Developed 3D models and design visualisations for client presentations.",
      "Supported design development and documentation; took part in project meetings.",
    ],
  },
];

export const skills = [
  {
    group: "Design & modelling",
    items: ["Revit", "AutoCAD", "SketchUp", "BIM (A.BIM certified)"],
  },
  {
    group: "Rendering & visualisation",
    items: ["Lumion", "D5 Render", "Enscape", "AI tools"],
  },
  {
    group: "Practice",
    items: [
      "Design development",
      "Construction documentation",
      "Authority approvals",
      "As-built documentation",
      "Technical coordination",
      "Site supervision",
    ],
  },
  {
    group: "Graphics & office",
    items: ["Photoshop", "Microsoft Office Suite"],
  },
  {
    group: "Project types",
    items: ["Villas", "Apartments", "Shops & restaurants", "Fit-out", "Exhibition stands"],
  },
];

export const education = [
  {
    title: "A.BIM (Architecture)",
    place: "Engineers CAD Center, Kozhikode, Kerala",
    period: "2024 – 2025",
  },
  {
    title: "Bachelor of Architecture (B.Arch)",
    place: "MES College of Architecture, Kakkodi, Kozhikode · University of Calicut",
    period: "2019 – 2024",
  },
];
